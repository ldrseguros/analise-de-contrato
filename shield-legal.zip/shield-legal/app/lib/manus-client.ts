
// Cliente para integração com a API Manus
import axios, { AxiosInstance, AxiosResponse } from 'axios';

export interface ManusConfig {
  apiKey: string;
  clientId: string;
  clientSecret: string;
  baseURL?: string;
}

export interface ManusAnalysisRequest {
  goal: string;
  context?: string;
  inputs?: any[];
  constraints?: {
    privacy?: string;
    deadline?: string;
    language?: string;
  };
  mode?: string;
  tool_coordination?: boolean;
}

export interface ManusAnalysisResponse {
  task_id: string;
  status: 'completed' | 'processing' | 'failed';
  result?: {
    analysis?: any;
    metadata?: {
      processing_time?: string;
      confidence_score?: number;
      tokens_used?: number;
    };
  };
  errors?: string[];
}

export interface ManusContractAnalysis {
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  identified_clauses: Array<{
    type: string;
    content: string;
    risk_assessment: string;
    recommendations: string[];
  }>;
  compliance_issues: any[];
  summary: string;
}

export class ManusClient {
  private client: AxiosInstance;
  private accessToken: string | null = null;
  private tokenExpiry: number | null = null;
  private config: ManusConfig;

  constructor(config: ManusConfig) {
    this.config = config;
    
    this.client = axios.create({
      baseURL: config.baseURL || 'https://api.manus-ai.com',
      timeout: 30000,
      headers: {
        'User-Agent': 'SHIELD-Legal/1.0',
        'Content-Type': 'application/json'
      }
    });

    // Interceptor para renovação automática de token
    this.client.interceptors.request.use(async (requestConfig) => {
      await this.ensureValidToken();
      requestConfig.headers.Authorization = `Bearer ${this.accessToken}`;
      requestConfig.headers['X-API-Key'] = this.config.apiKey;
      return requestConfig;
    });

    // Interceptor para tratamento de erros
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        throw this.handleError(error);
      }
    );
  }

  /**
   * Garante que temos um token válido
   */
  private async ensureValidToken(): Promise<void> {
    if (!this.accessToken || (this.tokenExpiry && Date.now() >= this.tokenExpiry)) {
      await this.refreshAccessToken();
    }
  }

  /**
   * Renova o token de acesso
   */
  private async refreshAccessToken(): Promise<void> {
    try {
      const response = await axios.post(`${this.config.baseURL || 'https://api.manus-ai.com'}/oauth/token`, 
        new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
          scope: 'agent:execute data:read workflow:modify'
        }), {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      this.accessToken = response.data.access_token;
      this.tokenExpiry = Date.now() + (response.data.expires_in * 1000);
    } catch (error) {
      throw new Error(`Falha na autenticação Manus: ${error}`);
    }
  }

  /**
   * Analisa um contrato usando a API Manus
   */
  async analyzeContract(
    document: string | Buffer, 
    analysisType: string = 'comprehensive'
  ): Promise<ManusAnalysisResponse> {
    const formData = new FormData();
    
    if (typeof document === 'string') {
      formData.append('file', document);
    } else {
      formData.append('file', new Blob([document]), 'document.pdf');
    }
    
    formData.append('analysis_type', analysisType);
    formData.append('language', 'pt-BR');

    const response = await this.client.post('/v2/contract/review', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'X-Compliance-Mode': 'GDPR'
      }
    });

    return response.data;
  }

  /**
   * Extrai cláusulas específicas de um documento
   */
  async extractClauses(
    document: string | Buffer, 
    clauseTypes: string[]
  ): Promise<ManusAnalysisResponse> {
    const request: ManusAnalysisRequest = {
      goal: `Extrair cláusulas específicas: ${clauseTypes.join(', ')}`,
      context: 'Documento jurídico para análise de conformidade',
      inputs: [document],
      constraints: {
        privacy: 'GDPR',
        language: 'pt-BR'
      }
    };

    const response = await this.client.post('/v2/text/extract', request);
    return response.data;
  }

  /**
   * Realiza decomposição de tarefas para análise complexa
   */
  async decomposeTask(
    goal: string, 
    context: string = '', 
    constraints: any = {}
  ): Promise<ManusAnalysisResponse> {
    const request: ManusAnalysisRequest = {
      goal,
      context,
      constraints: {
        privacy: 'GDPR',
        language: 'pt-BR',
        ...constraints
      }
    };

    const response = await this.client.post('/v2/decompose', request);
    return response.data;
  }

  /**
   * Analisa uma apólice de seguro
   */
  async analyzeInsurancePolicy(document: string | Buffer): Promise<ManusAnalysisResponse> {
    return this.decomposeTask(
      'Analisar apólice de seguro identificando coberturas, exclusões e procedimentos de sinistro',
      `Apólice de seguro para análise completa`,
      {
        analysis_type: 'insurance_policy',
        focus_areas: ['coverage_analysis', 'exclusions', 'claim_procedures', 'premium_calculation']
      }
    );
  }

  /**
   * Realiza análise cruzada entre contrato e apólice
   */
  async crossAnalysis(
    contract: string | Buffer, 
    policy: string | Buffer
  ): Promise<ManusAnalysisResponse> {
    return this.decomposeTask(
      'Realizar análise cruzada entre contrato e apólice identificando lacunas de cobertura e contradições',
      'Análise comparativa para identificação de riscos',
      {
        analysis_type: 'cross_analysis',
        documents: ['contract', 'insurance_policy'],
        focus_areas: ['coverage_gaps', 'contradictions', 'risk_assessment']
      }
    );
  }

  /**
   * Verifica o status de uma análise em andamento
   */
  async getAnalysisStatus(taskId: string): Promise<ManusAnalysisResponse> {
    const response = await this.client.get(`/v2/task/${taskId}/status`);
    return response.data;
  }

  /**
   * Obtém o resultado de uma análise concluída
   */
  async getAnalysisResult(taskId: string): Promise<ManusAnalysisResponse> {
    const response = await this.client.get(`/v2/task/${taskId}/result`);
    return response.data;
  }

  /**
   * Trata erros da API
   */
  private handleError(error: any): Error {
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 429:
          return new Error(`Rate limit excedido. Sugestão: ${data.mitigation || 'Aguarde antes de tentar novamente'}`);
        case 401:
          return new Error('Token de acesso inválido ou expirado');
        case 413:
          return new Error('Arquivo muito grande (máximo 50MB)');
        case 422:
          return new Error(`Parâmetros inválidos: ${data.message || 'Verifique os dados enviados'}`);
        default:
          return new Error(`Erro da API Manus (${status}): ${data.message || 'Erro desconhecido'}`);
      }
    }
    
    return new Error(`Erro de conexão com Manus: ${error.message}`);
  }

  /**
   * Sanitiza documento removendo dados sensíveis antes do envio
   */
  static sanitizeDocument(document: string): string {
    return document
      .replace(/\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/g, '[CPF_REDACTED]')
      .replace(/\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/g, '[CNPJ_REDACTED]')
      .replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, '[EMAIL_REDACTED]');
  }
}

/**
 * Classe especializada para integração SHIELD Legal
 */
export class ShieldLegalManus extends ManusClient {
  /**
   * Realiza análise completa para o sistema SHIELD Legal
   */
  async analyzeForShield(
    document: string | Buffer, 
    documentType: 'contract' | 'policy',
    options: any = {}
  ): Promise<{
    analysis: ManusAnalysisResponse;
    extractedClauses: ManusAnalysisResponse;
    taskBreakdown: ManusAnalysisResponse;
    shieldMetadata: {
      analysisTimestamp: string;
      confidenceScore: number;
      processingTime: string;
    };
  }> {
    try {
      // Análise principal do documento
      const analysis = documentType === 'contract' 
        ? await this.analyzeContract(document, options.type || 'comprehensive')
        : await this.analyzeInsurancePolicy(document);

      // Extração de cláusulas específicas
      const clauseTypes = [
        'confidentiality',
        'termination', 
        'liability',
        'payment_terms',
        'dispute_resolution',
        'coverage',
        'exclusion'
      ];

      const extractedClauses = await this.extractClauses(document, clauseTypes);

      // Decomposição de tarefas para análise detalhada
      const taskBreakdown = await this.decomposeTask(
        'Realizar análise jurídica completa identificando riscos e oportunidades',
        `${documentType === 'contract' ? 'Contrato' : 'Apólice'} analisado para sistema SHIELD Legal`,
        {
          focus_areas: ['legal_compliance', 'risk_assessment', 'optimization_opportunities']
        }
      );

      return {
        analysis,
        extractedClauses,
        taskBreakdown,
        shieldMetadata: {
          analysisTimestamp: new Date().toISOString(),
          confidenceScore: analysis.result?.metadata?.confidence_score || 0,
          processingTime: analysis.result?.metadata?.processing_time || 'N/A'
        }
      };

    } catch (error) {
      console.error('Erro na análise SHIELD Legal:', error);
      throw error;
    }
  }

  /**
   * Calcula o SHIELD Score baseado na análise Manus
   */
  calculateShieldScore(analysisResult: any): number {
    // Algoritmo proprietário para cálculo do SHIELD Score (0-1000)
    let score = 1000; // Começa com score máximo
    
    if (analysisResult.risk_level) {
      switch (analysisResult.risk_level) {
        case 'critical':
          score -= 400;
          break;
        case 'high':
          score -= 250;
          break;
        case 'medium':
          score -= 150;
          break;
        case 'low':
          score -= 50;
          break;
      }
    }

    // Reduz score baseado em problemas de compliance
    if (analysisResult.compliance_issues?.length > 0) {
      score -= analysisResult.compliance_issues.length * 50;
    }

    // Ajusta baseado na confiança da análise
    const confidence = analysisResult.metadata?.confidence_score || 1;
    score = Math.floor(score * confidence);

    return Math.max(0, Math.min(1000, score));
  }

  /**
   * Gera recomendações específicas do SHIELD Legal
   */
  generateShieldRecommendations(analysisResult: any): any[] {
    const recommendations = [];

    if (analysisResult.identified_clauses) {
      for (const clause of analysisResult.identified_clauses) {
        if (clause.risk_assessment === 'high' || clause.risk_assessment === 'critical') {
          recommendations.push({
            type: 'clause_risk',
            priority: clause.risk_assessment === 'critical' ? 'urgent' : 'high',
            title: `Risco identificado em cláusula de ${clause.type}`,
            description: clause.recommendations?.join('; ') || 'Revisar cláusula identificada',
            clause: clause
          });
        }
      }
    }

    if (analysisResult.compliance_issues?.length > 0) {
      recommendations.push({
        type: 'compliance',
        priority: 'high',
        title: 'Problemas de conformidade identificados',
        description: 'Revisar questões de conformidade regulatória',
        issues: analysisResult.compliance_issues
      });
    }

    return recommendations;
  }
}
