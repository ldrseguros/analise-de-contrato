
// Tipos TypeScript para o sistema SHIELD Legal

export interface User {
  id: string;
  email: string;
  name: string;
  profile: UserProfile;
  companyId?: string;
  permissions: string[];
  configurations?: any;
  isActive: boolean;
  lastAccess?: Date;
  createdAt: Date;
  updatedAt: Date;
  company?: Company;
}

export enum UserProfile {
  ADMIN = 'ADMIN',
  CONTRACT_ANALYST = 'CONTRACT_ANALYST',
  RISK_MANAGER = 'RISK_MANAGER',
  CONSULTANT = 'CONSULTANT',
  CLIENT = 'CLIENT',
  LEGAL_EXPERT = 'LEGAL_EXPERT',
  AUDITOR = 'AUDITOR'
}

export interface Company {
  id: string;
  name: string;
  cnpj?: string;
  sector: string;
  size: CompanySize;
  plan: string;
  configurations?: any;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export enum CompanySize {
  SMALL = 'SMALL',
  MEDIUM = 'MEDIUM',
  LARGE = 'LARGE'
}

export interface Document {
  id: string;
  name: string;
  type: DocumentType;
  version: number;
  filePath: string;
  fileSize: number;
  mimeType: string;
  hash: string;
  blockchainHash?: string;
  status: DocumentStatus;
  metadata?: any;
  uploadedById: string;
  companyId: string;
  createdAt: Date;
  updatedAt: Date;
  uploadedBy?: User;
  company?: Company;
  clauses?: Clause[];
  analyses?: Analysis[];
}

export enum DocumentType {
  CONTRACT = 'CONTRACT',
  INSURANCE_POLICY = 'INSURANCE_POLICY',
  GENERAL_CONDITIONS = 'GENERAL_CONDITIONS',
  ADDENDUM = 'ADDENDUM',
  ENDORSEMENT = 'ENDORSEMENT',
  REGULATION = 'REGULATION',
  OTHER = 'OTHER'
}

export enum DocumentStatus {
  UPLOADED = 'UPLOADED',
  PROCESSING = 'PROCESSING',
  ANALYZED = 'ANALYZED',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  ARCHIVED = 'ARCHIVED'
}

export interface Clause {
  id: string;
  documentId: string;
  type: ClauseType;
  content: string;
  position: number;
  riskIdentified: boolean;
  riskCategory?: RiskCategory;
  impact?: RiskImpact;
  confidence?: number;
  manusData?: any;
  createdAt: Date;
  updatedAt: Date;
}

export enum ClauseType {
  CONFIDENTIALITY = 'CONFIDENTIALITY',
  TERMINATION = 'TERMINATION',
  LIABILITY = 'LIABILITY',
  PAYMENT_TERMS = 'PAYMENT_TERMS',
  DISPUTE_RESOLUTION = 'DISPUTE_RESOLUTION',
  COVERAGE = 'COVERAGE',
  EXCLUSION = 'EXCLUSION',
  DEDUCTIBLE = 'DEDUCTIBLE',
  PREMIUM = 'PREMIUM',
  CLAIM_PROCEDURE = 'CLAIM_PROCEDURE',
  OTHER = 'OTHER'
}

export enum RiskCategory {
  PATRIMONIAL = 'PATRIMONIAL',
  CIVIL_LIABILITY = 'CIVIL_LIABILITY',
  OPERATIONAL = 'OPERATIONAL',
  CYBER = 'CYBER',
  REGULATORY = 'REGULATORY',
  CONTRACTUAL = 'CONTRACTUAL',
  GOVERNANCE = 'GOVERNANCE'
}

export enum RiskImpact {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export interface Analysis {
  id: string;
  documentId: string;
  type: AnalysisType;
  result: any;
  shieldScore?: number;
  riskLevel?: RiskImpact;
  contradictions?: any;
  gaps?: any;
  recommendations?: any;
  manusTaskId?: string;
  manusResult?: any;
  processingTime?: number;
  confidenceScore?: number;
  status: AnalysisStatus;
  analyzedById: string;
  createdAt: Date;
  updatedAt: Date;
  document?: Document;
  analyzedBy?: User;
  scenarios?: Scenario[];
}

export enum AnalysisType {
  INDIVIDUAL = 'INDIVIDUAL',
  CROSS_ANALYSIS = 'CROSS_ANALYSIS',
  PORTFOLIO = 'PORTFOLIO',
  COMPLIANCE = 'COMPLIANCE',
  JURISPRUDENCE = 'JURISPRUDENCE'
}

export enum AnalysisStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED'
}

export interface Scenario {
  id: string;
  analysisId: string;
  name: string;
  description: string;
  type: ScenarioType;
  parameters: any;
  impact: any;
  coverage: any;
  gaps?: any;
  recommendations?: any;
  createdAt: Date;
  updatedAt: Date;
}

export enum ScenarioType {
  PROPERTY_DAMAGE = 'PROPERTY_DAMAGE',
  BUSINESS_INTERRUPTION = 'BUSINESS_INTERRUPTION',
  CIVIL_LIABILITY = 'CIVIL_LIABILITY',
  CYBER_ATTACK = 'CYBER_ATTACK',
  REGULATORY_FINE = 'REGULATORY_FINE',
  PRODUCT_RECALL = 'PRODUCT_RECALL',
  NATURAL_DISASTER = 'NATURAL_DISASTER',
  CUSTOM = 'CUSTOM'
}

export interface Report {
  id: string;
  documentId?: string;
  name: string;
  type: ReportType;
  format: ReportFormat;
  content: any;
  filePath?: string;
  parameters?: any;
  generatedById: string;
  createdAt: Date;
  updatedAt: Date;
  document?: Document;
  generatedBy?: User;
}

export enum ReportType {
  ANALYSIS_SUMMARY = 'ANALYSIS_SUMMARY',
  RISK_ASSESSMENT = 'RISK_ASSESSMENT',
  COMPLIANCE = 'COMPLIANCE',
  RECOMMENDATIONS = 'RECOMMENDATIONS',
  SHIELD_SCORE = 'SHIELD_SCORE',
  EXECUTIVE = 'EXECUTIVE',
  TECHNICAL = 'TECHNICAL',
  COMPARATIVE = 'COMPARATIVE'
}

export enum ReportFormat {
  PDF = 'PDF',
  EXCEL = 'EXCEL',
  WORD = 'WORD',
  JSON = 'JSON',
  HTML = 'HTML'
}

// Interfaces para API responses
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T = any> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// Interfaces para Manus API
export interface ManusAnalysisRequest {
  goal: string;
  context?: string;
  inputs?: any[];
  constraints?: {
    privacy?: string;
    deadline?: string;
    language?: string;
  };
  mode?: string;
  tool_coordination?: boolean;
}

export interface ManusAnalysisResponse {
  task_id: string;
  status: 'completed' | 'processing' | 'failed';
  result?: {
    analysis?: any;
    metadata?: {
      processing_time?: string;
      confidence_score?: number;
      tokens_used?: number;
    };
  };
  errors?: string[];
}

// Interfaces para Dashboard
export interface DashboardStats {
  totalDocuments: number;
  totalAnalyses: number;
  averageShieldScore: number;
  riskDistribution: {
    low: number;
    medium: number;
    high: number;
    critical: number;
  };
  recentActivity: any[];
}

// Interfaces para Upload de documentos
export interface UploadProgress {
  documentId: string;
  progress: number;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  message?: string;
}

// Interfaces para Configurações
export interface UserSettings {
  notifications: {
    email: boolean;
    push: boolean;
    analysisComplete: boolean;
    riskAlerts: boolean;
  };
  dashboard: {
    defaultView: string;
    refreshInterval: number;
  };
  analysis: {
    autoAnalyze: boolean;
    defaultAnalysisType: AnalysisType;
  };
}

export interface CompanySettings {
  branding: {
    logo?: string;
    primaryColor: string;
    secondaryColor: string;
  };
  compliance: {
    lgpd: boolean;
    sector: string;
    regulations: string[];
  };
  integrations: {
    manus: boolean;
    blockchain: boolean;
    erp?: string;
  };
}
