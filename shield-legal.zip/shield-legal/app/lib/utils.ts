
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { RiskImpact, DocumentType, UserProfile } from "./types"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Formata bytes para formato legível
 */
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Formata data para formato brasileiro
 */
export function formatDate(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
}

/**
 * Formata data e hora para formato brasileiro
 */
export function formatDateTime(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Formata tempo relativo (ex: "há 2 horas")
 */
export function formatRelativeTime(date: Date | string): string {
  const d = new Date(date);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - d.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return 'agora mesmo';
  }

  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `há ${diffInMinutes} minuto${diffInMinutes > 1 ? 's' : ''}`;
  }

  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `há ${diffInHours} hora${diffInHours > 1 ? 's' : ''}`;
  }

  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 30) {
    return `há ${diffInDays} dia${diffInDays > 1 ? 's' : ''}`;
  }

  const diffInMonths = Math.floor(diffInDays / 30);
  if (diffInMonths < 12) {
    return `há ${diffInMonths} mês${diffInMonths > 1 ? 'es' : ''}`;
  }

  const diffInYears = Math.floor(diffInMonths / 12);
  return `há ${diffInYears} ano${diffInYears > 1 ? 's' : ''}`;
}

/**
 * Gera uma cor baseada no nível de risco
 */
export function getRiskColor(risk: RiskImpact): string {
  switch (risk) {
    case RiskImpact.LOW:
      return 'text-green-600 bg-green-50 border-green-200';
    case RiskImpact.MEDIUM:
      return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    case RiskImpact.HIGH:
      return 'text-orange-600 bg-orange-50 border-orange-200';
    case RiskImpact.CRITICAL:
      return 'text-red-600 bg-red-50 border-red-200';
    default:
      return 'text-gray-600 bg-gray-50 border-gray-200';
  }
}

/**
 * Traduz o nível de risco para português
 */
export function translateRiskLevel(risk: RiskImpact): string {
  switch (risk) {
    case RiskImpact.LOW:
      return 'Baixo';
    case RiskImpact.MEDIUM:
      return 'Médio';
    case RiskImpact.HIGH:
      return 'Alto';
    case RiskImpact.CRITICAL:
      return 'Crítico';
    default:
      return 'Não definido';
  }
}

/**
 * Traduz o tipo de documento para português
 */
export function translateDocumentType(type: DocumentType): string {
  switch (type) {
    case DocumentType.CONTRACT:
      return 'Contrato';
    case DocumentType.INSURANCE_POLICY:
      return 'Apólice de Seguro';
    case DocumentType.GENERAL_CONDITIONS:
      return 'Condições Gerais';
    case DocumentType.ADDENDUM:
      return 'Termo Aditivo';
    case DocumentType.ENDORSEMENT:
      return 'Endosso';
    case DocumentType.REGULATION:
      return 'Regulamento';
    case DocumentType.OTHER:
      return 'Outros';
    default:
      return 'Não definido';
  }
}

/**
 * Traduz o perfil de usuário para português
 */
export function translateUserProfile(profile: UserProfile): string {
  switch (profile) {
    case UserProfile.ADMIN:
      return 'Administrador';
    case UserProfile.CONTRACT_ANALYST:
      return 'Analista de Contratos';
    case UserProfile.RISK_MANAGER:
      return 'Gestor de Riscos';
    case UserProfile.CONSULTANT:
      return 'Consultor';
    case UserProfile.CLIENT:
      return 'Cliente';
    case UserProfile.LEGAL_EXPERT:
      return 'Especialista Jurídico';
    case UserProfile.AUDITOR:
      return 'Auditor';
    default:
      return 'Não definido';
  }
}

/**
 * Gera uma cor baseada no SHIELD Score
 */
export function getShieldScoreColor(score: number): string {
  if (score >= 800) {
    return 'text-green-600 bg-green-50';
  } else if (score >= 600) {
    return 'text-blue-600 bg-blue-50';
  } else if (score >= 400) {
    return 'text-yellow-600 bg-yellow-50';
  } else if (score >= 200) {
    return 'text-orange-600 bg-orange-50';
  } else {
    return 'text-red-600 bg-red-50';
  }
}

/**
 * Gera um nível baseado no SHIELD Score
 */
export function getShieldScoreLevel(score: number): string {
  if (score >= 800) {
    return 'Excelente';
  } else if (score >= 600) {
    return 'Bom';
  } else if (score >= 400) {
    return 'Regular';
  } else if (score >= 200) {
    return 'Ruim';
  } else {
    return 'Crítico';
  }
}

/**
 * Valida se um email é válido
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Valida se um CNPJ é válido
 */
export function isValidCNPJ(cnpj: string): boolean {
  cnpj = cnpj.replace(/[^\d]+/g, '');

  if (cnpj.length !== 14) return false;

  // Elimina CNPJs inválidos conhecidos
  if (/^(\d)\1+$/.test(cnpj)) return false;

  // Valida DVs
  let tamanho = cnpj.length - 2;
  let numeros = cnpj.substring(0, tamanho);
  let digitos = cnpj.substring(tamanho);
  let soma = 0;
  let pos = tamanho - 7;

  for (let i = tamanho; i >= 1; i--) {
    soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
    if (pos < 2) pos = 9;
  }

  let resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
  if (resultado !== parseInt(digitos.charAt(0))) return false;

  tamanho = tamanho + 1;
  numeros = cnpj.substring(0, tamanho);
  soma = 0;
  pos = tamanho - 7;

  for (let i = tamanho; i >= 1; i--) {
    soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
    if (pos < 2) pos = 9;
  }

  resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
  return resultado === parseInt(digitos.charAt(1));
}

/**
 * Formata CNPJ
 */
export function formatCNPJ(cnpj: string): string {
  cnpj = cnpj.replace(/[^\d]/g, '');
  return cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
}

/**
 * Gera um ID único
 */
export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

/**
 * Debounce function para otimizar chamadas de API
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Trunca texto mantendo palavras completas
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  
  const truncated = text.substring(0, maxLength);
  const lastSpace = truncated.lastIndexOf(' ');
  
  return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
}

/**
 * Converte string para slug
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^a-z0-9 -]/g, '') // Remove caracteres especiais
    .replace(/\s+/g, '-') // Substitui espaços por hífens
    .replace(/-+/g, '-') // Remove hífens duplicados
    .trim();
}

/**
 * Calcula a porcentagem de progresso
 */
export function calculateProgress(current: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((current / total) * 100);
}

/**
 * Formata número para moeda brasileira
 */
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

/**
 * Formata número com separadores de milhares
 */
export function formatNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(value);
}

/**
 * Gera uma cor aleatória em hexadecimal
 */
export function generateRandomColor(): string {
  return '#' + Math.floor(Math.random() * 16777215).toString(16);
}

/**
 * Verifica se uma string é um JSON válido
 */
export function isValidJSON(str: string): boolean {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
}

/**
 * Sanitiza HTML removendo tags perigosas
 */
export function sanitizeHTML(html: string): string {
  const allowedTags = ['p', 'br', 'strong', 'em', 'u', 'ol', 'ul', 'li'];
  const tagRegex = /<\/?([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/g;
  
  return html.replace(tagRegex, (match, tagName) => {
    return allowedTags.includes(tagName.toLowerCase()) ? match : '';
  });
}
