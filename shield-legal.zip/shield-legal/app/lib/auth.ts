
// Sistema de autenticação JWT para SHIELD Legal
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { NextRequest } from 'next/server';
import { prisma } from './db';
import { UserProfile } from './types';

const JWT_SECRET = process.env.JWT_SECRET || 'shield-legal-secret-key';
const JWT_EXPIRES_IN = '7d';

export interface JWTPayload {
  userId: string;
  email: string;
  profile: UserProfile;
  companyId?: string;
  permissions: string[];
}

/**
 * Gera um token JWT para o usuário
 */
export function generateToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

/**
 * Verifica e decodifica um token JWT
 */
export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Hash de senha usando bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

/**
 * Verifica se a senha está correta
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

/**
 * Extrai o token do header Authorization
 */
export function extractTokenFromRequest(request: NextRequest): string | null {
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return null;
}

/**
 * Middleware de autenticação para APIs
 */
export async function authenticateRequest(request: NextRequest): Promise<JWTPayload | null> {
  const token = extractTokenFromRequest(request);
  if (!token) {
    return null;
  }

  const payload = verifyToken(token);
  if (!payload) {
    return null;
  }

  // Verifica se o usuário ainda existe e está ativo
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    select: { id: true, isActive: true }
  });

  if (!user || !user.isActive) {
    return null;
  }

  return payload;
}

/**
 * Verifica se o usuário tem uma permissão específica
 */
export function hasPermission(userPayload: JWTPayload, permission: string): boolean {
  return userPayload.permissions.includes(permission) || userPayload.permissions.includes('*');
}

/**
 * Verifica se o usuário tem um dos perfis especificados
 */
export function hasProfile(userPayload: JWTPayload, profiles: UserProfile[]): boolean {
  return profiles.includes(userPayload.profile);
}

/**
 * Middleware de autorização baseado em perfis
 */
export function requireProfiles(profiles: UserProfile[]) {
  return (userPayload: JWTPayload): boolean => {
    return hasProfile(userPayload, profiles);
  };
}

/**
 * Middleware de autorização baseado em permissões
 */
export function requirePermissions(permissions: string[]) {
  return (userPayload: JWTPayload): boolean => {
    return permissions.every(permission => hasPermission(userPayload, permission));
  };
}

/**
 * Gera permissões padrão baseadas no perfil do usuário
 */
export function getDefaultPermissions(profile: UserProfile): string[] {
  const basePermissions = ['read:own_documents', 'read:own_analyses'];

  switch (profile) {
    case UserProfile.ADMIN:
      return ['*']; // Todas as permissões

    case UserProfile.CONTRACT_ANALYST:
      return [
        ...basePermissions,
        'create:documents',
        'update:documents',
        'create:analyses',
        'read:all_documents',
        'read:all_analyses',
        'generate:reports'
      ];

    case UserProfile.RISK_MANAGER:
      return [
        ...basePermissions,
        'create:scenarios',
        'read:all_analyses',
        'create:reports',
        'read:risk_data',
        'update:risk_assessments'
      ];

    case UserProfile.CONSULTANT:
      return [
        ...basePermissions,
        'create:documents',
        'create:analyses',
        'generate:client_reports',
        'read:client_data'
      ];

    case UserProfile.CLIENT:
      return [
        ...basePermissions,
        'create:documents',
        'read:own_reports'
      ];

    case UserProfile.LEGAL_EXPERT:
      return [
        ...basePermissions,
        'read:all_documents',
        'read:all_analyses',
        'create:legal_opinions',
        'read:jurisprudence',
        'update:compliance_status'
      ];

    case UserProfile.AUDITOR:
      return [
        ...basePermissions,
        'read:all_documents',
        'read:all_analyses',
        'read:audit_logs',
        'create:audit_reports',
        'read:compliance_data'
      ];

    default:
      return basePermissions;
  }
}

/**
 * Cria um usuário administrador padrão (para setup inicial)
 */
export async function createDefaultAdmin() {
  const adminEmail = 'admin@shieldlegal.com';
  
  const existingAdmin = await prisma.user.findUnique({
    where: { email: adminEmail }
  });

  if (existingAdmin) {
    return existingAdmin;
  }

  const hashedPassword = await hashPassword('admin123');
  
  return prisma.user.create({
    data: {
      email: adminEmail,
      password: hashedPassword,
      name: 'Administrador SHIELD Legal',
      profile: UserProfile.ADMIN,
      permissions: ['*'],
      isActive: true
    }
  });
}

/**
 * Registra uma ação no log de auditoria
 */
export async function logAuditAction(
  userId: string,
  action: string,
  resource: string,
  resourceId?: string,
  details?: any,
  ipAddress?: string,
  userAgent?: string
) {
  try {
    await prisma.auditLog.create({
      data: {
        userId,
        action,
        resource,
        resourceId,
        details,
        ipAddress,
        userAgent
      }
    });
  } catch (error) {
    console.error('Erro ao registrar log de auditoria:', error);
  }
}

/**
 * Atualiza o último acesso do usuário
 */
export async function updateLastAccess(userId: string) {
  try {
    await prisma.user.update({
      where: { id: userId },
      data: { lastAccess: new Date() }
    });
  } catch (error) {
    console.error('Erro ao atualizar último acesso:', error);
  }
}
