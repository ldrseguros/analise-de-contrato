
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  Shield, 
  LayoutDashboard, 
  FileText, 
  BarChart3, 
  FileOutput, 
  Settings, 
  LogOut,
  Menu,
  X,
  Upload,
  Users,
  AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { UserProfile } from '@/lib/types';

interface SidebarProps {
  user: any;
}

export function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('shield_token');
    localStorage.removeItem('shield_user');
    router.push('/');
  };

  const navigation = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      current: pathname === '/dashboard'
    },
    {
      name: 'Documentos',
      href: '/dashboard/documents',
      icon: FileText,
      current: pathname.startsWith('/dashboard/documents')
    },
    {
      name: 'Análises',
      href: '/dashboard/analyses',
      icon: BarChart3,
      current: pathname.startsWith('/dashboard/analyses')
    },
    {
      name: 'Relatórios',
      href: '/dashboard/reports',
      icon: FileOutput,
      current: pathname.startsWith('/dashboard/reports')
    }
  ];

  // Adiciona itens específicos por perfil
  if (user.profile === UserProfile.ADMIN || user.profile === UserProfile.RISK_MANAGER) {
    navigation.push({
      name: 'Usuários',
      href: '/dashboard/users',
      icon: Users,
      current: pathname.startsWith('/dashboard/users')
    });
  }

  if (user.profile === UserProfile.ADMIN) {
    navigation.push({
      name: 'Configurações',
      href: '/dashboard/settings',
      icon: Settings,
      current: pathname.startsWith('/dashboard/settings')
    });
  }

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center space-x-2 p-6 border-b border-gray-200">
        <Shield className="h-8 w-8 text-blue-600" />
        <span className="text-xl font-bold text-gray-900">SHIELD Legal</span>
      </div>

      {/* User Info */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
            <span className="text-white font-semibold">
              {user.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">
              {user.name}
            </p>
            <p className="text-xs text-gray-600 truncate">
              {user.email}
            </p>
          </div>
        </div>
        <Badge variant="secondary" className="mt-2 text-xs">
          {user.profile.replace('_', ' ')}
        </Badge>
      </div>

      {/* Quick Upload */}
      <div className="p-6 border-b border-gray-200">
        <Link href="/dashboard/documents/upload">
          <Button className="w-full bg-blue-600 hover:bg-blue-700">
            <Upload className="h-4 w-4 mr-2" />
            Novo Documento
          </Button>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-6 space-y-2">
        {navigation.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className={cn(
              'flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
              item.current
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-gray-700 hover:bg-gray-100'
            )}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <item.icon className="h-5 w-5" />
            <span>{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-6 border-t border-gray-200">
        <Button
          variant="ghost"
          onClick={handleLogout}
          className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sair
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="bg-white shadow-md"
        >
          {isMobileMenuOpen ? (
            <X className="h-4 w-4" />
          ) : (
            <Menu className="h-4 w-4" />
          )}
        </Button>
      </div>

      {/* Mobile sidebar */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="fixed left-0 top-0 h-full w-64 bg-white shadow-xl">
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-30 lg:w-64 lg:bg-white lg:border-r lg:border-gray-200">
        <SidebarContent />
      </div>
    </>
  );
}
