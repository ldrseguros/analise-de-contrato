
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { hashPassword, generateToken, getDefaultPermissions } from '@/lib/auth';
import { UserProfile } from '@/lib/types';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const registerSchema = z.object({
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
  profile: z.nativeEnum(UserProfile),
  companyName: z.string().optional(),
  companyCnpj: z.string().optional(),
  companySector: z.string().optional(),
  companySize: z.enum(['SMALL', 'MEDIUM', 'LARGE']).optional()
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validatedData = registerSchema.parse(body);

    // Verifica se o email já existe
    const existingUser = await prisma.user.findUnique({
      where: { email: validatedData.email }
    });

    if (existingUser) {
      return NextResponse.json(
        { success: false, error: 'Email já está em uso' },
        { status: 409 }
      );
    }

    // Hash da senha
    const hashedPassword = await hashPassword(validatedData.password);

    // Cria empresa se fornecida
    let companyId: string | undefined;
    if (validatedData.companyName) {
      const company = await prisma.company.create({
        data: {
          name: validatedData.companyName,
          cnpj: validatedData.companyCnpj,
          sector: validatedData.companySector || 'Não especificado',
          size: validatedData.companySize || 'SMALL',
          plan: 'basic'
        }
      });
      companyId = company.id;
    }

    // Cria o usuário
    const user = await prisma.user.create({
      data: {
        name: validatedData.name,
        email: validatedData.email,
        password: hashedPassword,
        profile: validatedData.profile,
        companyId,
        permissions: getDefaultPermissions(validatedData.profile),
        isActive: true
      },
      include: { company: true }
    });

    // Gera o token JWT
    const token = generateToken({
      userId: user.id,
      email: user.email,
      profile: user.profile as any,
      companyId: user.companyId || undefined,
      permissions: user.permissions
    });

    // Remove a senha da resposta
    const { password: _, ...userWithoutPassword } = user;

    return NextResponse.json({
      success: true,
      data: {
        token,
        user: userWithoutPassword
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Erro no registro:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Dados inválidos', details: error.errors },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
