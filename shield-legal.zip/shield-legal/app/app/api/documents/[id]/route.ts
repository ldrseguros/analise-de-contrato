
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission, logAuditAction } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    const document = await prisma.document.findUnique({
      where: { id: params.id },
      include: {
        uploadedBy: {
          select: { id: true, name: true, email: true }
        },
        company: {
          select: { id: true, name: true }
        },
        clauses: {
          orderBy: { position: 'asc' }
        },
        analyses: {
          orderBy: { createdAt: 'desc' },
          include: {
            analyzedBy: {
              select: { id: true, name: true }
            }
          }
        }
      }
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Documento não encontrado' },
        { status: 404 }
      );
    }

    // Verifica permissões
    const canAccess = 
      hasPermission(userPayload, 'read:all_documents') ||
      (userPayload.companyId === document.companyId && hasPermission(userPayload, 'read:company_documents')) ||
      (userPayload.userId === document.uploadedById && hasPermission(userPayload, 'read:own_documents'));

    if (!canAccess) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      data: document
    });

  } catch (error) {
    console.error('Erro ao buscar documento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    if (!hasPermission(userPayload, 'update:documents')) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, type, status, metadata } = body;

    const document = await prisma.document.findUnique({
      where: { id: params.id }
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Documento não encontrado' },
        { status: 404 }
      );
    }

    // Verifica se pode editar este documento
    const canEdit = 
      hasPermission(userPayload, 'update:all_documents') ||
      (userPayload.companyId === document.companyId && hasPermission(userPayload, 'update:company_documents')) ||
      userPayload.userId === document.uploadedById;

    if (!canEdit) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const updatedDocument = await prisma.document.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(type && { type }),
        ...(status && { status }),
        ...(metadata && { metadata }),
        updatedAt: new Date()
      },
      include: {
        uploadedBy: {
          select: { id: true, name: true, email: true }
        },
        company: {
          select: { id: true, name: true }
        }
      }
    });

    // Log de auditoria
    await logAuditAction(
      userPayload.userId,
      'UPDATE_DOCUMENT',
      'DOCUMENT',
      params.id,
      { changes: { name, type, status } },
      request.ip || undefined,
      request.headers.get('user-agent') || undefined
    );

    return NextResponse.json({
      success: true,
      data: updatedDocument
    });

  } catch (error) {
    console.error('Erro ao atualizar documento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    if (!hasPermission(userPayload, 'delete:documents')) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const document = await prisma.document.findUnique({
      where: { id: params.id }
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Documento não encontrado' },
        { status: 404 }
      );
    }

    // Verifica se pode deletar este documento
    const canDelete = 
      hasPermission(userPayload, 'delete:all_documents') ||
      (userPayload.companyId === document.companyId && hasPermission(userPayload, 'delete:company_documents')) ||
      userPayload.userId === document.uploadedById;

    if (!canDelete) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    await prisma.document.delete({
      where: { id: params.id }
    });

    // Log de auditoria
    await logAuditAction(
      userPayload.userId,
      'DELETE_DOCUMENT',
      'DOCUMENT',
      params.id,
      { documentName: document.name },
      request.ip || undefined,
      request.headers.get('user-agent') || undefined
    );

    return NextResponse.json({
      success: true,
      message: 'Documento excluído com sucesso'
    });

  } catch (error) {
    console.error('Erro ao excluir documento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
