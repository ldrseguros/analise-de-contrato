
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission, logAuditAction } from '@/lib/auth';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { createHash } from 'crypto';
import { DocumentType, DocumentStatus } from '@/lib/types';

export const dynamic = 'force-dynamic';

const UPLOAD_DIR = '/tmp/shield-legal-uploads';
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain'
];

export async function POST(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    if (!hasPermission(userPayload, 'create:documents')) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const documentType = formData.get('type') as DocumentType || DocumentType.OTHER;
    const name = formData.get('name') as string || file.name;

    if (!file) {
      return NextResponse.json(
        { success: false, error: 'Nenhum arquivo fornecido' },
        { status: 400 }
      );
    }

    // Validações do arquivo
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { success: false, error: 'Arquivo muito grande (máximo 50MB)' },
        { status: 413 }
      );
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        { success: false, error: 'Tipo de arquivo não suportado' },
        { status: 415 }
      );
    }

    // Cria diretório de upload se não existir
    await mkdir(UPLOAD_DIR, { recursive: true });

    // Lê o conteúdo do arquivo
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Gera hash do arquivo para integridade
    const hash = createHash('sha256').update(buffer).digest('hex');

    // Gera nome único para o arquivo
    const timestamp = Date.now();
    const fileName = `${timestamp}-${hash.substring(0, 8)}-${file.name}`;
    const filePath = join(UPLOAD_DIR, fileName);

    // Salva o arquivo
    await writeFile(filePath, buffer);

    // Salva no banco de dados
    const document = await prisma.document.create({
      data: {
        name,
        type: documentType,
        filePath,
        fileSize: file.size,
        mimeType: file.type,
        hash,
        status: DocumentStatus.UPLOADED,
        uploadedById: userPayload.userId,
        companyId: userPayload.companyId || '',
        metadata: {
          originalName: file.name,
          uploadedAt: new Date().toISOString()
        }
      },
      include: {
        uploadedBy: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    // Log de auditoria
    await logAuditAction(
      userPayload.userId,
      'UPLOAD_DOCUMENT',
      'DOCUMENT',
      document.id,
      { 
        fileName: file.name,
        fileSize: file.size,
        documentType 
      },
      request.ip || undefined,
      request.headers.get('user-agent') || undefined
    );

    return NextResponse.json({
      success: true,
      data: document
    }, { status: 201 });

  } catch (error) {
    console.error('Erro no upload:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
