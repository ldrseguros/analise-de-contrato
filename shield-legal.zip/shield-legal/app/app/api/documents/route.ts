
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission } from '@/lib/auth';
import { DocumentType, DocumentStatus } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type') as DocumentType;
    const status = searchParams.get('status') as DocumentStatus;
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    // Constrói filtros
    const where: any = {};

    // Filtro por empresa (se não for admin)
    if (userPayload.companyId && !hasPermission(userPayload, 'read:all_documents')) {
      where.companyId = userPayload.companyId;
    }

    // Filtro por usuário (se não tiver permissão para ver todos)
    if (!hasPermission(userPayload, 'read:all_documents') && !hasPermission(userPayload, 'read:company_documents')) {
      where.uploadedById = userPayload.userId;
    }

    if (type) {
      where.type = type;
    }

    if (status) {
      where.status = status;
    }

    if (search) {
      where.name = {
        contains: search,
        mode: 'insensitive'
      };
    }

    // Busca documentos
    const [documents, total] = await Promise.all([
      prisma.document.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          uploadedBy: {
            select: { id: true, name: true, email: true }
          },
          company: {
            select: { id: true, name: true }
          },
          _count: {
            select: {
              analyses: true,
              clauses: true
            }
          }
        }
      }),
      prisma.document.count({ where })
    ]);

    const totalPages = Math.ceil(total / limit);

    return NextResponse.json({
      success: true,
      data: {
        documents,
        pagination: {
          page,
          limit,
          total,
          totalPages
        }
      }
    });

  } catch (error) {
    console.error('Erro ao buscar documentos:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
