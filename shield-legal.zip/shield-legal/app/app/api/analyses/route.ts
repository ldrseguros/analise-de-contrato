
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission, logAuditAction } from '@/lib/auth';
import { ShieldLegalManus } from '@/lib/manus-client';
import { AnalysisType, AnalysisStatus, DocumentStatus } from '@/lib/types';
import { readFile } from 'fs/promises';

export const dynamic = 'force-dynamic';

// Inicializa cliente Manus (em produção, usar variáveis de ambiente reais)
const manusClient = new ShieldLegalManus({
  apiKey: process.env.MANUS_API_KEY || 'demo-key',
  clientId: process.env.MANUS_CLIENT_ID || 'demo-client',
  clientSecret: process.env.MANUS_CLIENT_SECRET || 'demo-secret'
});

export async function POST(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    if (!hasPermission(userPayload, 'create:analyses')) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { documentId, type = AnalysisType.INDIVIDUAL, options = {} } = body;

    // Busca o documento
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: { company: true }
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Documento não encontrado' },
        { status: 404 }
      );
    }

    // Verifica permissões de acesso ao documento
    const canAnalyze = 
      hasPermission(userPayload, 'analyze:all_documents') ||
      (userPayload.companyId === document.companyId && hasPermission(userPayload, 'analyze:company_documents')) ||
      userPayload.userId === document.uploadedById;

    if (!canAnalyze) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada para analisar este documento' },
        { status: 403 }
      );
    }

    // Cria registro de análise
    const analysis = await prisma.analysis.create({
      data: {
        documentId,
        type,
        result: {},
        status: AnalysisStatus.PENDING,
        analyzedById: userPayload.userId
      }
    });

    // Atualiza status do documento
    await prisma.document.update({
      where: { id: documentId },
      data: { status: DocumentStatus.PROCESSING }
    });

    // Inicia análise assíncrona
    processAnalysisAsync(analysis.id, document, type, options);

    // Log de auditoria
    await logAuditAction(
      userPayload.userId,
      'START_ANALYSIS',
      'ANALYSIS',
      analysis.id,
      { documentId, type },
      request.ip || undefined,
      request.headers.get('user-agent') || undefined
    );

    return NextResponse.json({
      success: true,
      data: analysis
    }, { status: 201 });

  } catch (error) {
    console.error('Erro ao iniciar análise:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const documentId = searchParams.get('documentId');
    const type = searchParams.get('type') as AnalysisType;
    const status = searchParams.get('status') as AnalysisStatus;

    const skip = (page - 1) * limit;

    // Constrói filtros
    const where: any = {};

    if (documentId) {
      where.documentId = documentId;
    }

    if (type) {
      where.type = type;
    }

    if (status) {
      where.status = status;
    }

    // Filtro por permissões
    if (!hasPermission(userPayload, 'read:all_analyses')) {
      if (userPayload.companyId && hasPermission(userPayload, 'read:company_analyses')) {
        where.document = {
          companyId: userPayload.companyId
        };
      } else {
        where.analyzedById = userPayload.userId;
      }
    }

    const [analyses, total] = await Promise.all([
      prisma.analysis.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          document: {
            select: { id: true, name: true, type: true }
          },
          analyzedBy: {
            select: { id: true, name: true }
          },
          scenarios: true
        }
      }),
      prisma.analysis.count({ where })
    ]);

    const totalPages = Math.ceil(total / limit);

    return NextResponse.json({
      success: true,
      data: {
        analyses,
        pagination: {
          page,
          limit,
          total,
          totalPages
        }
      }
    });

  } catch (error) {
    console.error('Erro ao buscar análises:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

// Função assíncrona para processar análise
async function processAnalysisAsync(
  analysisId: string,
  document: any,
  type: AnalysisType,
  options: any
) {
  try {
    // Atualiza status para processando
    await prisma.analysis.update({
      where: { id: analysisId },
      data: { status: AnalysisStatus.PROCESSING }
    });

    const startTime = Date.now();

    // Lê o arquivo do documento
    let fileContent: string | Buffer;
    try {
      fileContent = await readFile(document.filePath);
    } catch (error) {
      throw new Error('Erro ao ler arquivo do documento');
    }

    // Determina o tipo de documento para análise
    const documentType = document.type === 'INSURANCE_POLICY' ? 'policy' : 'contract';

    // Realiza análise usando Manus
    const manusResult = await manusClient.analyzeForShield(
      fileContent,
      documentType,
      options
    );

    // Calcula SHIELD Score
    const shieldScore = manusClient.calculateShieldScore(manusResult.analysis.result);

    // Gera recomendações
    const recommendations = manusClient.generateShieldRecommendations(manusResult.analysis.result);

    // Determina nível de risco
    const riskLevel = determineRiskLevel(shieldScore);

    const processingTime = Date.now() - startTime;

    // Atualiza análise com resultados
    await prisma.analysis.update({
      where: { id: analysisId },
      data: {
        result: manusResult.analysis.result,
        shieldScore,
        riskLevel,
        recommendations,
        manusTaskId: manusResult.analysis.task_id,
        manusResult: manusResult as any,
        processingTime,
        confidenceScore: manusResult.shieldMetadata.confidenceScore,
        status: AnalysisStatus.COMPLETED
      }
    });

    // Extrai e salva cláusulas identificadas
    if (manusResult.extractedClauses.result?.analysis?.identified_clauses) {
      await saveExtractedClauses(document.id, manusResult.extractedClauses.result.analysis.identified_clauses);
    }

    // Atualiza status do documento
    await prisma.document.update({
      where: { id: document.id },
      data: { status: DocumentStatus.ANALYZED }
    });

    console.log(`Análise ${analysisId} concluída com sucesso`);

  } catch (error) {
    console.error(`Erro na análise ${analysisId}:`, error);

    // Atualiza análise com erro
    await prisma.analysis.update({
      where: { id: analysisId },
      data: {
        status: AnalysisStatus.FAILED,
        result: {
          error: error instanceof Error ? error.message : 'Erro desconhecido'
        }
      }
    });

    // Reverte status do documento
    await prisma.document.update({
      where: { id: document.id },
      data: { status: DocumentStatus.UPLOADED }
    });
  }
}

// Função para determinar nível de risco baseado no SHIELD Score
function determineRiskLevel(score: number) {
  if (score >= 800) return 'LOW';
  if (score >= 600) return 'MEDIUM';
  if (score >= 400) return 'HIGH';
  return 'CRITICAL';
}

// Função para salvar cláusulas extraídas
async function saveExtractedClauses(documentId: string, clauses: any[]) {
  try {
    const clauseData = clauses.map((clause, index) => ({
      documentId,
      type: mapClauseType(clause.type),
      content: clause.content,
      position: index + 1,
      riskIdentified: clause.risk_assessment === 'high' || clause.risk_assessment === 'critical',
      riskCategory: mapRiskCategory(clause.type),
      impact: mapRiskImpact(clause.risk_assessment),
      confidence: clause.confidence || 0.8,
      manusData: clause
    }));

    await prisma.clause.createMany({
      data: clauseData as any,
      skipDuplicates: true
    });

  } catch (error) {
    console.error('Erro ao salvar cláusulas:', error);
  }
}

// Mapeia tipos de cláusula do Manus para o sistema
function mapClauseType(manusType: string) {
  const mapping: { [key: string]: string } = {
    'confidentiality': 'CONFIDENTIALITY',
    'termination': 'TERMINATION',
    'liability': 'LIABILITY',
    'payment_terms': 'PAYMENT_TERMS',
    'dispute_resolution': 'DISPUTE_RESOLUTION',
    'coverage': 'COVERAGE',
    'exclusion': 'EXCLUSION',
    'deductible': 'DEDUCTIBLE',
    'premium': 'PREMIUM',
    'claim_procedure': 'CLAIM_PROCEDURE'
  };

  return mapping[manusType] || 'OTHER';
}

// Mapeia categoria de risco
function mapRiskCategory(clauseType: string) {
  const mapping: { [key: string]: string } = {
    'liability': 'CIVIL_LIABILITY',
    'coverage': 'PATRIMONIAL',
    'exclusion': 'PATRIMONIAL',
    'confidentiality': 'CONTRACTUAL',
    'termination': 'CONTRACTUAL',
    'payment_terms': 'CONTRACTUAL',
    'dispute_resolution': 'CONTRACTUAL'
  };

  return mapping[clauseType] || 'CONTRACTUAL';
}

// Mapeia impacto do risco
function mapRiskImpact(riskAssessment: string) {
  const mapping: { [key: string]: string } = {
    'low': 'LOW',
    'medium': 'MEDIUM',
    'high': 'HIGH',
    'critical': 'CRITICAL'
  };

  return mapping[riskAssessment] || 'MEDIUM';
}
