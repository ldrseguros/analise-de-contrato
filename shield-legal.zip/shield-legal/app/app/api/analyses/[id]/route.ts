
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    const analysis = await prisma.analysis.findUnique({
      where: { id: params.id },
      include: {
        document: {
          include: {
            company: {
              select: { id: true, name: true }
            },
            uploadedBy: {
              select: { id: true, name: true }
            },
            clauses: {
              orderBy: { position: 'asc' }
            }
          }
        },
        analyzedBy: {
          select: { id: true, name: true, email: true }
        },
        scenarios: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!analysis) {
      return NextResponse.json(
        { success: false, error: 'Análise não encontrada' },
        { status: 404 }
      );
    }

    // Verifica permissões
    const canAccess = 
      hasPermission(userPayload, 'read:all_analyses') ||
      (userPayload.companyId === analysis.document.companyId && hasPermission(userPayload, 'read:company_analyses')) ||
      (userPayload.userId === analysis.analyzedById && hasPermission(userPayload, 'read:own_analyses'));

    if (!canAccess) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      data: analysis
    });

  } catch (error) {
    console.error('Erro ao buscar análise:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
