
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission, logAuditAction } from '@/lib/auth';
import { ReportType, ReportFormat } from '@/lib/types';
import PDFDocument from 'pdfkit';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

export const dynamic = 'force-dynamic';

const REPORTS_DIR = '/tmp/shield-legal-reports';

export async function POST(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    if (!hasPermission(userPayload, 'generate:reports')) {
      return NextResponse.json(
        { success: false, error: 'Permissão negada' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { 
      name, 
      type, 
      format = ReportFormat.PDF, 
      documentId, 
      analysisId,
      parameters = {} 
    } = body;

    // Validações
    if (!name || !type) {
      return NextResponse.json(
        { success: false, error: 'Nome e tipo do relatório são obrigatórios' },
        { status: 400 }
      );
    }

    // Busca dados necessários para o relatório
    let reportData: any = {};
    
    if (documentId) {
      const document = await prisma.document.findUnique({
        where: { id: documentId },
        include: {
          company: true,
          uploadedBy: { select: { id: true, name: true } },
          clauses: true,
          analyses: {
            orderBy: { createdAt: 'desc' },
            take: 1,
            include: { scenarios: true }
          }
        }
      });

      if (!document) {
        return NextResponse.json(
          { success: false, error: 'Documento não encontrado' },
          { status: 404 }
        );
      }

      reportData.document = document;
    }

    if (analysisId) {
      const analysis = await prisma.analysis.findUnique({
        where: { id: analysisId },
        include: {
          document: {
            include: { company: true, clauses: true }
          },
          analyzedBy: { select: { id: true, name: true } },
          scenarios: true
        }
      });

      if (!analysis) {
        return NextResponse.json(
          { success: false, error: 'Análise não encontrada' },
          { status: 404 }
        );
      }

      reportData.analysis = analysis;
    }

    // Gera conteúdo do relatório
    const content = await generateReportContent(type, reportData, parameters);

    // Gera arquivo se necessário
    let filePath: string | undefined;
    if (format === ReportFormat.PDF) {
      filePath = await generatePDFReport(name, content);
    }

    // Salva relatório no banco
    const report = await prisma.report.create({
      data: {
        name,
        type,
        format,
        content,
        filePath,
        parameters,
        documentId,
        generatedById: userPayload.userId
      },
      include: {
        document: {
          select: { id: true, name: true }
        },
        generatedBy: {
          select: { id: true, name: true }
        }
      }
    });

    // Log de auditoria
    await logAuditAction(
      userPayload.userId,
      'GENERATE_REPORT',
      'REPORT',
      report.id,
      { type, format, documentId, analysisId },
      request.ip || undefined,
      request.headers.get('user-agent') || undefined
    );

    return NextResponse.json({
      success: true,
      data: report
    }, { status: 201 });

  } catch (error) {
    console.error('Erro ao gerar relatório:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type') as ReportType;
    const format = searchParams.get('format') as ReportFormat;

    const skip = (page - 1) * limit;

    // Constrói filtros
    const where: any = {};

    if (type) {
      where.type = type;
    }

    if (format) {
      where.format = format;
    }

    // Filtro por permissões
    if (!hasPermission(userPayload, 'read:all_reports')) {
      where.generatedById = userPayload.userId;
    }

    const [reports, total] = await Promise.all([
      prisma.report.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          document: {
            select: { id: true, name: true, type: true }
          },
          generatedBy: {
            select: { id: true, name: true }
          }
        }
      }),
      prisma.report.count({ where })
    ]);

    const totalPages = Math.ceil(total / limit);

    return NextResponse.json({
      success: true,
      data: {
        reports,
        pagination: {
          page,
          limit,
          total,
          totalPages
        }
      }
    });

  } catch (error) {
    console.error('Erro ao buscar relatórios:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

// Função para gerar conteúdo do relatório
async function generateReportContent(
  type: ReportType,
  data: any,
  parameters: any
): Promise<any> {
  const content: any = {
    title: '',
    sections: [],
    metadata: {
      generatedAt: new Date().toISOString(),
      type,
      parameters
    }
  };

  switch (type) {
    case ReportType.ANALYSIS_SUMMARY:
      content.title = 'Resumo de Análise';
      content.sections = [
        {
          title: 'Informações do Documento',
          data: {
            name: data.analysis?.document?.name || data.document?.name,
            type: data.analysis?.document?.type || data.document?.type,
            uploadDate: data.analysis?.document?.createdAt || data.document?.createdAt
          }
        },
        {
          title: 'Resultado da Análise',
          data: {
            shieldScore: data.analysis?.shieldScore,
            riskLevel: data.analysis?.riskLevel,
            status: data.analysis?.status,
            processingTime: data.analysis?.processingTime
          }
        },
        {
          title: 'Recomendações',
          data: data.analysis?.recommendations || []
        }
      ];
      break;

    case ReportType.RISK_ASSESSMENT:
      content.title = 'Avaliação de Riscos';
      content.sections = [
        {
          title: 'Análise de Riscos',
          data: {
            riskLevel: data.analysis?.riskLevel,
            identifiedRisks: data.analysis?.result?.identified_clauses?.filter((c: any) => 
              c.risk_assessment === 'high' || c.risk_assessment === 'critical'
            ) || []
          }
        },
        {
          title: 'Cenários de Risco',
          data: data.analysis?.scenarios || []
        }
      ];
      break;

    case ReportType.SHIELD_SCORE:
      content.title = 'SHIELD Score';
      content.sections = [
        {
          title: 'Pontuação SHIELD',
          data: {
            score: data.analysis?.shieldScore,
            level: getShieldScoreLevel(data.analysis?.shieldScore || 0),
            breakdown: calculateScoreBreakdown(data.analysis)
          }
        }
      ];
      break;

    default:
      content.title = 'Relatório Personalizado';
      content.sections = [
        {
          title: 'Dados',
          data: data
        }
      ];
  }

  return content;
}

// Função para gerar PDF
async function generatePDFReport(name: string, content: any): Promise<string> {
  await mkdir(REPORTS_DIR, { recursive: true });

  const fileName = `${Date.now()}-${name.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
  const filePath = join(REPORTS_DIR, fileName);

  const doc = new PDFDocument();
  const chunks: Buffer[] = [];

  doc.on('data', chunk => chunks.push(chunk));
  
  return new Promise((resolve, reject) => {
    doc.on('end', async () => {
      try {
        const pdfBuffer = Buffer.concat(chunks);
        await writeFile(filePath, pdfBuffer);
        resolve(filePath);
      } catch (error) {
        reject(error);
      }
    });

    // Gera conteúdo do PDF
    doc.fontSize(20).text(content.title, 50, 50);
    doc.moveDown();

    content.sections.forEach((section: any, index: number) => {
      if (index > 0) doc.addPage();
      
      doc.fontSize(16).text(section.title, 50, 100);
      doc.moveDown();
      
      doc.fontSize(12).text(JSON.stringify(section.data, null, 2), 50, 130);
    });

    doc.end();
  });
}

// Função auxiliar para calcular nível do SHIELD Score
function getShieldScoreLevel(score: number): string {
  if (score >= 800) return 'Excelente';
  if (score >= 600) return 'Bom';
  if (score >= 400) return 'Regular';
  if (score >= 200) return 'Ruim';
  return 'Crítico';
}

// Função auxiliar para calcular breakdown do score
function calculateScoreBreakdown(analysis: any): any {
  return {
    base: 1000,
    riskDeductions: analysis?.riskLevel === 'CRITICAL' ? 400 : 
                   analysis?.riskLevel === 'HIGH' ? 250 :
                   analysis?.riskLevel === 'MEDIUM' ? 150 : 50,
    complianceDeductions: (analysis?.result?.compliance_issues?.length || 0) * 50,
    finalScore: analysis?.shieldScore || 0
  };
}
