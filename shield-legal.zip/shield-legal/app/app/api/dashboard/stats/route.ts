
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { authenticateRequest, hasPermission } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const userPayload = await authenticateRequest(request);
    
    if (!userPayload) {
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      );
    }

    // Constrói filtros baseados nas permissões
    const documentFilter: any = {};
    const analysisFilter: any = {};

    if (!hasPermission(userPayload, 'read:all_documents')) {
      if (userPayload.companyId && hasPermission(userPayload, 'read:company_documents')) {
        documentFilter.companyId = userPayload.companyId;
        analysisFilter.document = { companyId: userPayload.companyId };
      } else {
        documentFilter.uploadedById = userPayload.userId;
        analysisFilter.analyzedById = userPayload.userId;
      }
    }

    // Busca estatísticas básicas
    const [
      totalDocuments,
      totalAnalyses,
      completedAnalyses,
      recentDocuments,
      recentAnalyses,
      riskDistribution,
      averageShieldScore
    ] = await Promise.all([
      // Total de documentos
      prisma.document.count({ where: documentFilter }),
      
      // Total de análises
      prisma.analysis.count({ where: analysisFilter }),
      
      // Análises concluídas
      prisma.analysis.count({ 
        where: { ...analysisFilter, status: 'COMPLETED' } 
      }),
      
      // Documentos recentes (últimos 7 dias)
      prisma.document.findMany({
        where: {
          ...documentFilter,
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          uploadedBy: { select: { name: true } },
          _count: { select: { analyses: true } }
        }
      }),
      
      // Análises recentes
      prisma.analysis.findMany({
        where: {
          ...analysisFilter,
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          document: { select: { name: true, type: true } },
          analyzedBy: { select: { name: true } }
        }
      }),
      
      // Distribuição de riscos
      prisma.analysis.groupBy({
        by: ['riskLevel'],
        where: { ...analysisFilter, status: 'COMPLETED' },
        _count: { riskLevel: true }
      }),
      
      // SHIELD Score médio
      prisma.analysis.aggregate({
        where: { 
          ...analysisFilter, 
          status: 'COMPLETED',
          shieldScore: { not: null }
        },
        _avg: { shieldScore: true }
      })
    ]);

    // Processa distribuição de riscos
    const riskStats = {
      LOW: 0,
      MEDIUM: 0,
      HIGH: 0,
      CRITICAL: 0
    };

    riskDistribution.forEach(item => {
      if (item.riskLevel) {
        riskStats[item.riskLevel as keyof typeof riskStats] = item._count.riskLevel;
      }
    });

    // Busca estatísticas por tipo de documento
    const documentTypeStats = await prisma.document.groupBy({
      by: ['type'],
      where: documentFilter,
      _count: { type: true }
    });

    // Busca tendências mensais (últimos 6 meses)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyTrends = await prisma.document.groupBy({
      by: ['createdAt'],
      where: {
        ...documentFilter,
        createdAt: { gte: sixMonthsAgo }
      },
      _count: { createdAt: true }
    });

    // Processa tendências mensais
    const monthlyData = Array.from({ length: 6 }, (_, i) => {
      const date = new Date();
      date.setMonth(date.getMonth() - (5 - i));
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      const count = monthlyTrends.filter(item => {
        const itemDate = new Date(item.createdAt);
        const itemKey = `${itemDate.getFullYear()}-${String(itemDate.getMonth() + 1).padStart(2, '0')}`;
        return itemKey === monthKey;
      }).length;

      return {
        month: monthKey,
        count
      };
    });

    const stats = {
      overview: {
        totalDocuments,
        totalAnalyses,
        completedAnalyses,
        averageShieldScore: Math.round(averageShieldScore._avg.shieldScore || 0),
        analysisCompletionRate: totalAnalyses > 0 ? Math.round((completedAnalyses / totalAnalyses) * 100) : 0
      },
      riskDistribution: riskStats,
      documentTypes: documentTypeStats.reduce((acc, item) => {
        acc[item.type] = item._count.type;
        return acc;
      }, {} as Record<string, number>),
      monthlyTrends: monthlyData,
      recentActivity: {
        documents: recentDocuments,
        analyses: recentAnalyses
      }
    };

    return NextResponse.json({
      success: true,
      data: stats
    });

  } catch (error) {
    console.error('Erro ao buscar estatísticas:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
