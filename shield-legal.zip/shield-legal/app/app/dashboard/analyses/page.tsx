
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { 
  BarChart3, 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { motion } from 'framer-motion';
import { formatRelativeTime, getShieldScoreColor, getShieldScoreLevel, translateRiskLevel } from '@/lib/utils';
import { AnalysisType, AnalysisStatus, RiskImpact } from '@/lib/types';

interface Analysis {
  id: string;
  type: AnalysisType;
  status: AnalysisStatus;
  shieldScore?: number;
  riskLevel?: RiskImpact;
  createdAt: string;
  document: {
    id: string;
    name: string;
    type: string;
  };
  analyzedBy: {
    name: string;
  };
}

export default function AnalysesPage() {
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchAnalyses();
  }, [currentPage, typeFilter, statusFilter, searchTerm]);

  const fetchAnalyses = async () => {
    try {
      const token = localStorage.getItem('shield_token');
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: '10',
        ...(typeFilter !== 'all' && { type: typeFilter }),
        ...(statusFilter !== 'all' && { status: statusFilter })
      });

      const response = await fetch(`/api/analyses?${params}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAnalyses(data.data.analyses);
        setTotalPages(data.data.pagination.totalPages);
      }
    } catch (error) {
      console.error('Erro ao buscar análises:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: AnalysisStatus) => {
    switch (status) {
      case AnalysisStatus.PENDING:
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case AnalysisStatus.PROCESSING:
        return <BarChart3 className="h-4 w-4 text-blue-600" />;
      case AnalysisStatus.COMPLETED:
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case AnalysisStatus.FAILED:
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: AnalysisStatus) => {
    const statusConfig = {
      PENDING: { label: 'Pendente', variant: 'secondary' as const },
      PROCESSING: { label: 'Processando', variant: 'default' as const },
      COMPLETED: { label: 'Concluída', variant: 'default' as const },
      FAILED: { label: 'Falhou', variant: 'destructive' as const },
      CANCELLED: { label: 'Cancelada', variant: 'outline' as const }
    };

    const config = statusConfig[status] || statusConfig.PENDING;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Análises</h1>
            <p className="text-gray-600">Acompanhe suas análises de documentos</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-gray-200 rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Análises</h1>
          <p className="text-gray-600">Acompanhe suas análises de documentos</p>
        </div>
        <Link href="/dashboard/documents">
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Nova Análise
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar análises..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Tipo de análise" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="INDIVIDUAL">Individual</SelectItem>
                <SelectItem value="CROSS_ANALYSIS">Análise Cruzada</SelectItem>
                <SelectItem value="PORTFOLIO">Portfólio</SelectItem>
                <SelectItem value="COMPLIANCE">Conformidade</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="PENDING">Pendente</SelectItem>
                <SelectItem value="PROCESSING">Processando</SelectItem>
                <SelectItem value="COMPLETED">Concluída</SelectItem>
                <SelectItem value="FAILED">Falhou</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Analyses Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Análises ({analyses.length})</CardTitle>
            <CardDescription>
              Lista de todas as análises realizadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            {analyses.length === 0 ? (
              <div className="text-center py-12">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhuma análise encontrada
                </h3>
                <p className="text-gray-600 mb-4">
                  Comece carregando um documento e iniciando uma análise.
                </p>
                <Link href="/dashboard/documents/upload">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Carregar Documento
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Documento</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>SHIELD Score</TableHead>
                      <TableHead>Risco</TableHead>
                      <TableHead>Analisado</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {analyses.map((analysis) => (
                      <TableRow key={analysis.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <FileText className="h-5 w-5 text-gray-400" />
                            <div>
                              <p className="font-medium text-gray-900">
                                {analysis.document.name}
                              </p>
                              <p className="text-sm text-gray-600">
                                Por {analysis.analyzedBy.name}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {analysis.type.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(analysis.status)}
                            {getStatusBadge(analysis.status)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {analysis.shieldScore ? (
                            <div className="flex items-center space-x-2">
                              <Shield className="h-4 w-4 text-blue-600" />
                              <Badge className={getShieldScoreColor(analysis.shieldScore)}>
                                {analysis.shieldScore}
                              </Badge>
                            </div>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {analysis.riskLevel ? (
                            <Badge variant={
                              analysis.riskLevel === 'CRITICAL' ? 'destructive' :
                              analysis.riskLevel === 'HIGH' ? 'destructive' :
                              analysis.riskLevel === 'MEDIUM' ? 'default' : 'secondary'
                            }>
                              {translateRiskLevel(analysis.riskLevel)}
                            </Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {formatRelativeTime(analysis.createdAt)}
                        </TableCell>
                        <TableCell>
                          <Link href={`/dashboard/analyses/${analysis.id}`}>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  Anterior
                </Button>
                <span className="flex items-center px-4 text-sm text-gray-600">
                  Página {currentPage} de {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  Próxima
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
