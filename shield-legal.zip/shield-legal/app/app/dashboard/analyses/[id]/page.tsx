
'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, 
  BarChart3, 
  FileText, 
  Shield, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Download,
  Share2,
  Target,
  TrendingUp,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { 
  formatDateTime, 
  getRiskColor, 
  translateRiskLevel,
  getShieldScoreColor,
  getShieldScoreLevel
} from '@/lib/utils';

interface AnalysisDetails {
  id: string;
  type: string;
  status: string;
  shieldScore?: number;
  riskLevel?: string;
  result: any;
  recommendations?: any[];
  processingTime?: number;
  confidenceScore?: number;
  createdAt: string;
  document: {
    id: string;
    name: string;
    type: string;
    clauses: Array<{
      id: string;
      type: string;
      content: string;
      riskIdentified: boolean;
      riskCategory?: string;
      impact?: string;
    }>;
  };
  analyzedBy: {
    name: string;
    email: string;
  };
  scenarios: Array<{
    id: string;
    name: string;
    type: string;
    description: string;
    impact: any;
  }>;
}

export default function AnalysisDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [analysis, setAnalysis] = useState<AnalysisDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (params.id) {
      fetchAnalysis(params.id as string);
    }
  }, [params.id]);

  const fetchAnalysis = async (analysisId: string) => {
    try {
      const token = localStorage.getItem('shield_token');
      const response = await fetch(`/api/analyses/${analysisId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAnalysis(data.data);
      } else if (response.status === 404) {
        router.push('/dashboard/analyses');
      }
    } catch (error) {
      console.error('Erro ao buscar análise:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateReport = async () => {
    try {
      const token = localStorage.getItem('shield_token');
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: `Relatório de Análise - ${analysis?.document.name}`,
          type: 'ANALYSIS_SUMMARY',
          format: 'PDF',
          analysisId: analysis?.id
        })
      });

      if (response.ok) {
        // Aqui você pode implementar o download do relatório
        console.log('Relatório gerado com sucesso');
      }
    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-8 w-48 bg-gray-200 rounded animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-32 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="text-center py-12">
        <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Análise não encontrada
        </h3>
        <Link href="/dashboard/analyses">
          <Button variant="outline">Voltar para análises</Button>
        </Link>
      </div>
    );
  }

  const riskyClauses = analysis.document.clauses.filter(clause => clause.riskIdentified);
  const isCompleted = analysis.status === 'COMPLETED';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/dashboard/analyses">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Análise: {analysis.document.name}
            </h1>
            <p className="text-gray-600">
              {analysis.type.replace('_', ' ')} • {formatDateTime(analysis.createdAt)}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={generateReport}>
            <Download className="h-4 w-4 mr-2" />
            Relatório
          </Button>
          <Button variant="outline">
            <Share2 className="h-4 w-4 mr-2" />
            Compartilhar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Status Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                    <span>Status da Análise</span>
                  </CardTitle>
                  <Badge variant={isCompleted ? 'default' : 'secondary'} className={isCompleted ? 'bg-green-600' : ''}>
                    {isCompleted ? 'Concluída' : 'Em Processamento'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {isCompleted ? (
                  <div className="space-y-6">
                    {/* SHIELD Score */}
                    <div className="text-center">
                      <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full text-3xl font-bold ${getShieldScoreColor(analysis.shieldScore || 0)}`}>
                        {analysis.shieldScore}
                      </div>
                      <p className="text-xl font-medium text-gray-900 mt-3">
                        {getShieldScoreLevel(analysis.shieldScore || 0)}
                      </p>
                      <p className="text-sm text-gray-600">SHIELD Score</p>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold text-gray-900">{analysis.document.clauses.length}</p>
                        <p className="text-sm text-gray-600">Cláusulas</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-red-600">{riskyClauses.length}</p>
                        <p className="text-sm text-gray-600">Riscos</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-blue-600">{analysis.scenarios.length}</p>
                        <p className="text-sm text-gray-600">Cenários</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-green-600">
                          {Math.round((analysis.confidenceScore || 0) * 100)}%
                        </p>
                        <p className="text-sm text-gray-600">Confiança</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-lg font-medium text-gray-900 mb-2">
                      Análise em processamento
                    </p>
                    <p className="text-gray-600 mb-4">
                      Aguarde enquanto processamos seu documento
                    </p>
                    <Progress value={75} className="w-full max-w-xs mx-auto" />
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Detailed Results */}
          {isCompleted && (
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="risks">Riscos</TabsTrigger>
                <TabsTrigger value="scenarios">Cenários</TabsTrigger>
                <TabsTrigger value="recommendations">Recomendações</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle>Resumo da Análise</CardTitle>
                    <CardDescription>
                      Principais descobertas e métricas
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Risk Level */}
                      {analysis.riskLevel && (
                        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <AlertTriangle className="h-6 w-6 text-orange-600" />
                            <div>
                              <p className="font-medium">Nível de Risco Geral</p>
                              <p className="text-sm text-gray-600">Baseado na análise completa</p>
                            </div>
                          </div>
                          <Badge className={getRiskColor(analysis.riskLevel as any)} variant="outline">
                            {translateRiskLevel(analysis.riskLevel as any)}
                          </Badge>
                        </div>
                      )}

                      {/* Processing Info */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <Clock className="h-5 w-5 text-blue-600" />
                            <span className="font-medium">Tempo de Processamento</span>
                          </div>
                          <p className="text-2xl font-bold text-blue-600">
                            {analysis.processingTime ? `${Math.round(analysis.processingTime / 1000)}s` : 'N/A'}
                          </p>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <Target className="h-5 w-5 text-green-600" />
                            <span className="font-medium">Precisão</span>
                          </div>
                          <p className="text-2xl font-bold text-green-600">
                            {Math.round((analysis.confidenceScore || 0) * 100)}%
                          </p>
                        </div>
                      </div>

                      {/* Summary */}
                      {analysis.result?.summary && (
                        <div>
                          <h4 className="font-medium mb-2">Resumo Executivo</h4>
                          <p className="text-gray-700 leading-relaxed">
                            {analysis.result.summary}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="risks">
                <Card>
                  <CardHeader>
                    <CardTitle>Riscos Identificados ({riskyClauses.length})</CardTitle>
                    <CardDescription>
                      Cláusulas que apresentam riscos potenciais
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {riskyClauses.length === 0 ? (
                      <div className="text-center py-8">
                        <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                        <p className="text-lg font-medium text-gray-900 mb-2">
                          Nenhum risco crítico identificado
                        </p>
                        <p className="text-gray-600">
                          O documento apresenta baixo nível de risco
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {riskyClauses.map((clause) => (
                          <div key={clause.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center space-x-2">
                                <Badge variant="outline">
                                  {clause.type.replace('_', ' ')}
                                </Badge>
                                <Badge variant="destructive">Risco</Badge>
                              </div>
                              {clause.impact && (
                                <Badge className={getRiskColor(clause.impact as any)}>
                                  {translateRiskLevel(clause.impact as any)}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-700 leading-relaxed mb-3">
                              {clause.content}
                            </p>
                            {clause.riskCategory && (
                              <div className="text-xs text-gray-600">
                                Categoria: {clause.riskCategory.replace('_', ' ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="scenarios">
                <Card>
                  <CardHeader>
                    <CardTitle>Cenários de Risco ({analysis.scenarios.length})</CardTitle>
                    <CardDescription>
                      Simulações de possíveis situações
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {analysis.scenarios.length === 0 ? (
                      <div className="text-center py-8">
                        <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">
                          Nenhum cenário específico foi simulado para esta análise
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {analysis.scenarios.map((scenario) => (
                          <div key={scenario.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-medium">{scenario.name}</h4>
                              <Badge variant="outline">
                                {scenario.type.replace('_', ' ')}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700 mb-3">
                              {scenario.description}
                            </p>
                            {scenario.impact && (
                              <div className="text-xs text-gray-600">
                                Impacto estimado: {JSON.stringify(scenario.impact)}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recommendations">
                <Card>
                  <CardHeader>
                    <CardTitle>Recomendações</CardTitle>
                    <CardDescription>
                      Sugestões para melhorar a proteção
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!analysis.recommendations || analysis.recommendations.length === 0 ? (
                      <div className="text-center py-8">
                        <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">
                          Nenhuma recomendação específica gerada para esta análise
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {analysis.recommendations.map((recommendation, index) => (
                          <div key={index} className="border rounded-lg p-4">
                            <div className="flex items-start space-x-3">
                              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                <span className="text-xs font-medium text-blue-600">
                                  {index + 1}
                                </span>
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium mb-1">
                                  {recommendation.title || `Recomendação ${index + 1}`}
                                </h4>
                                <p className="text-sm text-gray-700">
                                  {recommendation.description || JSON.stringify(recommendation)}
                                </p>
                                {recommendation.priority && (
                                  <Badge 
                                    variant={recommendation.priority === 'urgent' ? 'destructive' : 'default'}
                                    className="mt-2"
                                  >
                                    {recommendation.priority}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Document Info */}
          <Card>
            <CardHeader>
              <CardTitle>Documento Analisado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <FileText className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="font-medium">{analysis.document.name}</p>
                  <p className="text-sm text-gray-600">{analysis.document.type}</p>
                </div>
              </div>
              <Link href={`/dashboard/documents/${analysis.document.id}`}>
                <Button variant="outline" className="w-full">
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Documento
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Analysis Info */}
          <Card>
            <CardHeader>
              <CardTitle>Informações da Análise</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium">Tipo</p>
                <p className="text-sm text-gray-600">{analysis.type.replace('_', ' ')}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Analisado por</p>
                <p className="text-sm text-gray-600">{analysis.analyzedBy.name}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Data</p>
                <p className="text-sm text-gray-600">{formatDateTime(analysis.createdAt)}</p>
              </div>
              {analysis.processingTime && (
                <div>
                  <p className="text-sm font-medium">Tempo de processamento</p>
                  <p className="text-sm text-gray-600">
                    {Math.round(analysis.processingTime / 1000)} segundos
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Ações</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={generateReport} className="w-full bg-blue-600 hover:bg-blue-700">
                <Download className="h-4 w-4 mr-2" />
                Gerar Relatório PDF
              </Button>
              <Button variant="outline" className="w-full">
                <Share2 className="h-4 w-4 mr-2" />
                Compartilhar Análise
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
