
'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, 
  FileText, 
  BarChart3, 
  Download, 
  Share2, 
  MoreHorizontal,
  Calendar,
  User,
  HardDrive,
  Shield,
  AlertTriangle,
  CheckCircle,
  Clock,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { motion } from 'framer-motion';
import { 
  formatBytes, 
  formatDateTime, 
  translateDocumentType, 
  getRiskColor, 
  translateRiskLevel,
  getShieldScoreColor,
  getShieldScoreLevel
} from '@/lib/utils';

interface DocumentDetails {
  id: string;
  name: string;
  type: string;
  status: string;
  fileSize: number;
  createdAt: string;
  uploadedBy: {
    name: string;
    email: string;
  };
  company: {
    name: string;
  };
  clauses: Array<{
    id: string;
    type: string;
    content: string;
    riskIdentified: boolean;
    riskCategory?: string;
    impact?: string;
  }>;
  analyses: Array<{
    id: string;
    type: string;
    status: string;
    shieldScore?: number;
    riskLevel?: string;
    createdAt: string;
    analyzedBy: {
      name: string;
    };
  }>;
}

export default function DocumentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [document, setDocument] = useState<DocumentDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (params.id) {
      fetchDocument(params.id as string);
    }
  }, [params.id]);

  const fetchDocument = async (documentId: string) => {
    try {
      const token = localStorage.getItem('shield_token');
      const response = await fetch(`/api/documents/${documentId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setDocument(data.data);
      } else if (response.status === 404) {
        router.push('/dashboard/documents');
      }
    } catch (error) {
      console.error('Erro ao buscar documento:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const startAnalysis = async () => {
    try {
      const token = localStorage.getItem('shield_token');
      const response = await fetch('/api/analyses', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          documentId: document?.id,
          type: 'INDIVIDUAL'
        })
      });

      if (response.ok) {
        // Recarrega o documento para mostrar a nova análise
        fetchDocument(params.id as string);
      }
    } catch (error) {
      console.error('Erro ao iniciar análise:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <div className="h-8 w-8 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-8 w-48 bg-gray-200 rounded animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-32 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="text-center py-12">
        <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Documento não encontrado
        </h3>
        <Link href="/dashboard/documents">
          <Button variant="outline">Voltar para documentos</Button>
        </Link>
      </div>
    );
  }

  const latestAnalysis = document.analyses[0];
  const riskyClauses = document.clauses.filter(clause => clause.riskIdentified);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/dashboard/documents">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{document.name}</h1>
            <p className="text-gray-600">
              {translateDocumentType(document.type as any)} • {formatBytes(document.fileSize)}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
          <Button variant="outline">
            <Share2 className="h-4 w-4 mr-2" />
            Compartilhar
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Editar informações</DropdownMenuItem>
              <DropdownMenuItem>Arquivar documento</DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                Excluir documento
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Analysis Overview */}
          {latestAnalysis && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-blue-600" />
                      <span>Análise SHIELD</span>
                    </CardTitle>
                    {latestAnalysis.status === 'COMPLETED' && (
                      <Badge variant="default" className="bg-green-600">
                        Concluída
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {latestAnalysis.status === 'COMPLETED' ? (
                    <div className="space-y-6">
                      {/* SHIELD Score */}
                      <div className="text-center">
                        <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full text-2xl font-bold ${getShieldScoreColor(latestAnalysis.shieldScore || 0)}`}>
                          {latestAnalysis.shieldScore}
                        </div>
                        <p className="text-lg font-medium text-gray-900 mt-2">
                          {getShieldScoreLevel(latestAnalysis.shieldScore || 0)}
                        </p>
                        <p className="text-sm text-gray-600">SHIELD Score</p>
                      </div>

                      {/* Risk Level */}
                      {latestAnalysis.riskLevel && (
                        <div className="flex items-center justify-center space-x-2">
                          <AlertTriangle className="h-5 w-5 text-orange-600" />
                          <span className="text-sm font-medium">Nível de Risco:</span>
                          <Badge className={getRiskColor(latestAnalysis.riskLevel as any)}>
                            {translateRiskLevel(latestAnalysis.riskLevel as any)}
                          </Badge>
                        </div>
                      )}

                      {/* Quick Stats */}
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-2xl font-bold text-gray-900">{document.clauses.length}</p>
                          <p className="text-sm text-gray-600">Cláusulas</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-red-600">{riskyClauses.length}</p>
                          <p className="text-sm text-gray-600">Riscos</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-green-600">
                            {document.clauses.length - riskyClauses.length}
                          </p>
                          <p className="text-sm text-gray-600">OK</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-lg font-medium text-gray-900 mb-2">
                        Análise em andamento
                      </p>
                      <p className="text-gray-600 mb-4">
                        O documento está sendo processado pela nossa IA
                      </p>
                      <Progress value={65} className="w-full max-w-xs mx-auto" />
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Tabs */}
          <Tabs defaultValue="clauses" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="clauses">Cláusulas</TabsTrigger>
              <TabsTrigger value="analyses">Análises</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>

            <TabsContent value="clauses">
              <Card>
                <CardHeader>
                  <CardTitle>Cláusulas Identificadas ({document.clauses.length})</CardTitle>
                  <CardDescription>
                    Cláusulas extraídas automaticamente do documento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {document.clauses.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">
                        Nenhuma cláusula identificada ainda. Inicie uma análise para extrair as cláusulas.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {document.clauses.map((clause) => (
                        <div key={clause.id} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline">
                                {clause.type.replace('_', ' ')}
                              </Badge>
                              {clause.riskIdentified && (
                                <Badge variant="destructive">Risco Identificado</Badge>
                              )}
                            </div>
                            {clause.impact && (
                              <Badge className={getRiskColor(clause.impact as any)}>
                                {translateRiskLevel(clause.impact as any)}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-700 leading-relaxed">
                            {clause.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analyses">
              <Card>
                <CardHeader>
                  <CardTitle>Histórico de Análises ({document.analyses.length})</CardTitle>
                  <CardDescription>
                    Todas as análises realizadas neste documento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {document.analyses.length === 0 ? (
                    <div className="text-center py-8">
                      <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">
                        Nenhuma análise realizada ainda
                      </p>
                      <Button onClick={startAnalysis} className="bg-blue-600 hover:bg-blue-700">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Iniciar Análise
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {document.analyses.map((analysis) => (
                        <div key={analysis.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <BarChart3 className="h-4 w-4 text-gray-600" />
                              <span className="font-medium">
                                {analysis.type.replace('_', ' ')}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2">
                              {analysis.shieldScore && (
                                <Badge className={getShieldScoreColor(analysis.shieldScore)}>
                                  {analysis.shieldScore}
                                </Badge>
                              )}
                              <Link href={`/dashboard/analyses/${analysis.id}`}>
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-2" />
                                  Ver Detalhes
                                </Button>
                              </Link>
                            </div>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Analisado por {analysis.analyzedBy.name}</p>
                            <p>{formatDateTime(analysis.createdAt)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>Histórico do Documento</CardTitle>
                  <CardDescription>
                    Linha do tempo de atividades
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Documento carregado</p>
                        <p className="text-xs text-gray-600">
                          {formatDateTime(document.createdAt)} por {document.uploadedBy.name}
                        </p>
                      </div>
                    </div>
                    {document.analyses.map((analysis) => (
                      <div key={analysis.id} className="flex items-start space-x-3">
                        <BarChart3 className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium">
                            Análise {analysis.status === 'COMPLETED' ? 'concluída' : 'iniciada'}
                          </p>
                          <p className="text-xs text-gray-600">
                            {formatDateTime(analysis.createdAt)} por {analysis.analyzedBy.name}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Document Info */}
          <Card>
            <CardHeader>
              <CardTitle>Informações do Documento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <Calendar className="h-4 w-4 text-gray-600" />
                <div>
                  <p className="text-sm font-medium">Data de Upload</p>
                  <p className="text-xs text-gray-600">{formatDateTime(document.createdAt)}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <User className="h-4 w-4 text-gray-600" />
                <div>
                  <p className="text-sm font-medium">Carregado por</p>
                  <p className="text-xs text-gray-600">{document.uploadedBy.name}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <HardDrive className="h-4 w-4 text-gray-600" />
                <div>
                  <p className="text-sm font-medium">Tamanho</p>
                  <p className="text-xs text-gray-600">{formatBytes(document.fileSize)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Ações Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {!latestAnalysis && (
                <Button 
                  onClick={startAnalysis} 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Iniciar Análise
                </Button>
              )}
              {latestAnalysis && (
                <Link href={`/dashboard/analyses/${latestAnalysis.id}`}>
                  <Button variant="outline" className="w-full">
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Análise Completa
                  </Button>
                </Link>
              )}
              <Button variant="outline" className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Gerar Relatório
              </Button>
            </CardContent>
          </Card>

          {/* Risk Summary */}
          {riskyClauses.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <span>Resumo de Riscos</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Cláusulas de Risco</span>
                    <Badge variant="destructive">{riskyClauses.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Cláusulas Seguras</span>
                    <Badge variant="default" className="bg-green-600">
                      {document.clauses.length - riskyClauses.length}
                    </Badge>
                  </div>
                  <Progress 
                    value={(riskyClauses.length / document.clauses.length) * 100} 
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-600 text-center">
                    {Math.round((riskyClauses.length / document.clauses.length) * 100)}% das cláusulas apresentam riscos
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
