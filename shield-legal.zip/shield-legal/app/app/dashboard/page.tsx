
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  FileText, 
  BarChart3, 
  Shield, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Upload,
  Eye
} from 'lucide-react';
import { motion } from 'framer-motion';
import { formatRelativeTime, getShieldScoreColor, getShieldScoreLevel } from '@/lib/utils';
import Link from 'next/link';

interface DashboardStats {
  overview: {
    totalDocuments: number;
    totalAnalyses: number;
    completedAnalyses: number;
    averageShieldScore: number;
    analysisCompletionRate: number;
  };
  riskDistribution: {
    LOW: number;
    MEDIUM: number;
    HIGH: number;
    CRITICAL: number;
  };
  documentTypes: Record<string, number>;
  monthlyTrends: Array<{
    month: string;
    count: number;
  }>;
  recentActivity: {
    documents: any[];
    analyses: any[];
  };
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const token = localStorage.getItem('shield_token');
      const response = await fetch('/api/dashboard/stats', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setStats(data.data);
      }
    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const overviewCards = [
    {
      title: 'Total de Documentos',
      value: stats?.overview.totalDocuments || 0,
      icon: FileText,
      color: 'text-blue-600 bg-blue-50',
      description: 'Documentos carregados'
    },
    {
      title: 'Análises Realizadas',
      value: stats?.overview.totalAnalyses || 0,
      icon: BarChart3,
      color: 'text-green-600 bg-green-50',
      description: `${stats?.overview.analysisCompletionRate || 0}% concluídas`
    },
    {
      title: 'SHIELD Score Médio',
      value: stats?.overview.averageShieldScore || 0,
      icon: Shield,
      color: getShieldScoreColor(stats?.overview.averageShieldScore || 0),
      description: getShieldScoreLevel(stats?.overview.averageShieldScore || 0)
    },
    {
      title: 'Taxa de Conclusão',
      value: `${stats?.overview.analysisCompletionRate || 0}%`,
      icon: TrendingUp,
      color: 'text-purple-600 bg-purple-50',
      description: 'Análises finalizadas'
    }
  ];

  const riskLevels = [
    { level: 'CRITICAL', label: 'Crítico', color: 'bg-red-500', count: stats?.riskDistribution.CRITICAL || 0 },
    { level: 'HIGH', label: 'Alto', color: 'bg-orange-500', count: stats?.riskDistribution.HIGH || 0 },
    { level: 'MEDIUM', label: 'Médio', color: 'bg-yellow-500', count: stats?.riskDistribution.MEDIUM || 0 },
    { level: 'LOW', label: 'Baixo', color: 'bg-green-500', count: stats?.riskDistribution.LOW || 0 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Visão geral da sua análise de documentos</p>
        </div>
        <div className="flex space-x-3">
          <Link href="/dashboard/documents/upload">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Upload className="h-4 w-4 mr-2" />
              Novo Documento
            </Button>
          </Link>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {overviewCards.map((card, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  {card.title}
                </CardTitle>
                <div className={`p-2 rounded-lg ${card.color}`}>
                  <card.icon className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  {card.value}
                </div>
                <p className="text-xs text-gray-600">
                  {card.description}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Distribuição de Riscos */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-orange-600" />
                <span>Distribuição de Riscos</span>
              </CardTitle>
              <CardDescription>
                Análise dos níveis de risco identificados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {riskLevels.map((risk) => (
                  <div key={risk.level} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${risk.color}`}></div>
                      <span className="text-sm font-medium">{risk.label}</span>
                    </div>
                    <Badge variant="secondary">{risk.count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Atividade Recente */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-600" />
                <span>Atividade Recente</span>
              </CardTitle>
              <CardDescription>
                Últimos documentos e análises
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Documentos Recentes */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Documentos Recentes</h4>
                  <div className="space-y-2">
                    {stats?.recentActivity.documents.slice(0, 3).map((doc) => (
                      <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-4 w-4 text-gray-600" />
                          <div>
                            <p className="text-sm font-medium text-gray-900">{doc.name}</p>
                            <p className="text-xs text-gray-600">
                              {formatRelativeTime(doc.createdAt)} • {doc.uploadedBy?.name}
                            </p>
                          </div>
                        </div>
                        <Link href={`/dashboard/documents/${doc.id}`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Análises Recentes */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Análises Recentes</h4>
                  <div className="space-y-2">
                    {stats?.recentActivity.analyses.slice(0, 3).map((analysis) => (
                      <div key={analysis.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <BarChart3 className="h-4 w-4 text-gray-600" />
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {analysis.document?.name}
                            </p>
                            <div className="flex items-center space-x-2">
                              <p className="text-xs text-gray-600">
                                {formatRelativeTime(analysis.createdAt)}
                              </p>
                              {analysis.status === 'COMPLETED' && (
                                <CheckCircle className="h-3 w-3 text-green-600" />
                              )}
                            </div>
                          </div>
                        </div>
                        {analysis.shieldScore && (
                          <Badge className={getShieldScoreColor(analysis.shieldScore)}>
                            {analysis.shieldScore}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>
              Acesse rapidamente as principais funcionalidades
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link href="/dashboard/documents/upload">
                <Button variant="outline" className="w-full h-20 flex flex-col space-y-2">
                  <Upload className="h-6 w-6" />
                  <span>Carregar Documento</span>
                </Button>
              </Link>
              <Link href="/dashboard/documents">
                <Button variant="outline" className="w-full h-20 flex flex-col space-y-2">
                  <FileText className="h-6 w-6" />
                  <span>Ver Documentos</span>
                </Button>
              </Link>
              <Link href="/dashboard/analyses">
                <Button variant="outline" className="w-full h-20 flex flex-col space-y-2">
                  <BarChart3 className="h-6 w-6" />
                  <span>Ver Análises</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
